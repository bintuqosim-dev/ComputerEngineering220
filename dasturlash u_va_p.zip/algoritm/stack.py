class Stack:
    def __init__(self):
        self.stack = []

    # Stack ga yangi element qo'shish
    def push(self, item):
        self.stack.append(item)
        print(f"{item} stekga qo'shildi.")

    # Stack dan elementni olish (o'chirish)
    def pop(self):
        if not self.is_empty():
            item = self.stack.pop()
            print(f"{item} stekdan olindi.")
            return item
        else:
            print("Stek bo'sh!")

    # Stackning oxirgi elementini ko'rish
    def peek(self):
        if not self.is_empty():
            return self.stack[-1]
        else:
            print("Stek bo'sh!")

    # Stackning bo'sh yoki to'liqligini tekshirish
    def is_empty(self):
        return len(self.stack) == 0

    # Stackdagi elementlarni ko'rsatish
    def display(self):
        print("Stack:", self.stack)

# Stack ob'ekti yaratamiz
stack = Stack()

# Stack operatsiyalarini amalga oshiramiz
stack.push(10)
stack.push(20)
stack.push(30)
stack.display()

print("Oxirgi element:", stack.peek())
stack.pop()
stack.display()
print("Stack bo'shmi?", stack.is_empty())
